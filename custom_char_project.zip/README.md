# Carattere Personalizzato 8x8 (Custom Character DLL & GitHub Workflow)

Questo pacchetto contiene tutti i file necessari per compilare e gestire il carattere personalizzato a scacchiera 8x8.

## Contenuto del Pacchetto

- `milli.c`: Codice sorgente C configurato per la generazione della DLL Windows.
- `main.c`: Codice sorgente di esempio per testare il carattere 8x8.
- `.github/workflows/compile-dll.yml`: Workflow di GitHub Actions per la compilazione automatica in `.dll`.

## Come utilizzare su GitHub
1. Carica questi file all'interno del tuo repository GitHub.
2. Assicurati che il file del workflow si trovi nel percorso `.github/workflows/compile-dll.yml`.
3. Ad ogni `push`, GitHub compilera automaticamente la DLL e la rendera scaricabile nella scheda **Actions**.
